#SXD20|20302|50729|70405|2021.01.03 19:40:17|project|0|7|2|
#TA category`0`0|companies`0`0|companies_add_edit`2`2296|locality`0`0|migrations`0`0|region`0`0|review`0`0
#EOH

#	TC`category`utf8_general_ci	;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` char(250) NOT NULL,
  `name` char(250) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_2` (`name`),
  KEY `name` (`name`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=3473 DEFAULT CHARSET=utf8	;
#	TC`companies`utf8_general_ci	;
CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `region_id` int(11) NOT NULL,
  `locality_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `postalcode` varchar(250) NOT NULL,
  `streetaddress` varchar(250) NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `telephone` varchar(250) NOT NULL,
  `fax` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `website` varchar(250) NOT NULL,
  `descr` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `streetaddress` (`streetaddress`)
) ENGINE=MyISAM AUTO_INCREMENT=2672724 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC	;
#	TC`companies_add_edit`utf8_general_ci	;
CREATE TABLE `companies_add_edit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `edit` text NOT NULL,
  `ip` varchar(20) NOT NULL,
  `type` enum('add','edit') NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  `url` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `region_name` varchar(250) NOT NULL,
  `locality_name` varchar(250) NOT NULL,
  `category_name` varchar(250) NOT NULL,
  `postalcode` varchar(250) NOT NULL,
  `streetaddress` varchar(250) NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `telephone` varchar(250) NOT NULL,
  `website` varchar(250) NOT NULL,
  `descr` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8	;
#	TD`companies_add_edit`utf8_general_ci	;
INSERT INTO `companies_add_edit` VALUES 
(63,0,'sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf','127.0.0.1','add','2021-01-02 10:55:22','1','wedadasd','wedadasd','Prince Edward Island','Oshawa','Contractors - General','123123','Ул. Молодогвардейская 12/1 Кв 45',0.0000000,0.0000000,'+375333833626','www.mcmahonetfils.com','123123123123123123123123'),
(64,4,'Перевод контекст \"коммент\" c русский на немецкий от Reverso Context: Я подумала, если я напишу этот коммент, ты прекратишь.','127.0.0.1','edit','2021-01-02 11:17:29','0','wilson-j-craig','vadim','Ontario','Cambridge','Lawyers','12345','2 Water St N,Cambridge,ON N1R 3B1',43.3590740,-80.3153490,'519-622-0192','www.mcmahonetfils.com','Out of all the entities in Cambridge, Wilson J Craig may be one of the best Lawyers in Ontario. You can visit TITLE at their Cambridge location at 2 Water St N,Cambridge,ON N1R 3B1. Located in Cambridge, Wilson J Craig is a Farm Equipment corporation. Look to Wilson J Craig if you are in need of Lawyers. If you need to get in touch with someone, you can reach them by phone at 519-622-0192.<br><br><b>Opening Hours</b><br>Please call 519-622-0192 for opening hours.')	;
#	TC`locality`utf8_general_ci	;
CREATE TABLE `locality` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  `region_id` tinyint(3) unsigned NOT NULL,
  `name` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `region_id` (`region_id`,`name`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=8528 DEFAULT CHARSET=utf8	;
#	TC`migrations`utf8mb4_unicode_ci	;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci	;
#	TC`region`utf8_general_ci	;
CREATE TABLE `region` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8	;
#	TC`review`utf8_general_ci	;
CREATE TABLE `review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` char(100) NOT NULL,
  `email` char(100) NOT NULL,
  `review` text NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` char(15) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id` (`company_id`,`status`,`added`)
) ENGINE=MyISAM AUTO_INCREMENT=1286 DEFAULT CHARSET=utf8	;
